package com.birddash;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
        setContentView(new GameView(this));
    }

    static class Rock {
        float x,y,size,speed;
        Rock(float x,float y,float size,float speed){this.x=x;this.y=y;this.size=size;this.speed=speed;}
    }

    class GameView extends View {
        Paint p = new Paint();
        Random random = new Random();
        ArrayList<Rock> rocks = new ArrayList<>();
        SharedPreferences prefs;
        float birdX=0.25f,birdY=0.5f, targetX=0.25f,targetY=0.5f;
        long last=0, spawn=0;
        int score=0,best=0;
        boolean playing=false, over=false;
        float scale, w,h;
        GameView(Context c){super(c); p.setAntiAlias(false); prefs=getSharedPreferences("bird_dash",0); best=prefs.getInt("best",0); setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void color(int c){p.setColor(c);}
        void rect(Canvas c,int col,float x,float y,float ww,float hh){color(col);c.drawRect(x,y,x+ww,y+hh,p);}
        void text(Canvas c,String s,float x,float y,int size,int col){p.setTypeface(Typeface.create("monospace",Typeface.BOLD));p.setTextSize(size);color(col);c.drawText(s,x,y,p);}
        void start(){rocks.clear();score=0;birdX=targetX=.24f;birdY=targetY=.5f;playing=true;over=false;last=System.currentTimeMillis();spawn=0;invalidate();}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); w=getWidth();h=getHeight();
            c.drawColor(Color.rgb(13,9,31));
            // Pixel stars and distant mountains
            for(int i=0;i<42;i++){float sx=(i*83)%Math.max(1,(int)w), sy=(i*137)%Math.max(1,(int)(h*.72));rect(c,0xFF7566A8,sx,sy,3,3);}
            for(int i=0;i<8;i++){float mx=i*w/7f;rect(c,0xFF21183F,mx,h*.78f, w/7f+2,h*.22f);rect(c,0xFF34245A,mx+10,h*.78f-18,w/14f,18);}
            rect(c,0xFF17112F,0,h*.91f,w,h*.09f);
            if(playing){
                long now=System.currentTimeMillis();float dt=Math.min(.04f,(now-last)/1000f);last=now;
                score+=(int)(dt*10);
                float speed= w*(.42f+score*.0015f);
                birdX += (targetX-birdX)*Math.min(1,dt*10); birdY+=(targetY-birdY)*Math.min(1,dt*10);
                spawn+=(long)(dt*1000);
                if(spawn>Math.max(480,1150-score*2)){rocks.add(new Rock(w+30, h*(.12f+random.nextFloat()*.75f), 24+random.nextInt(19), speed));spawn=0;}
                for(int i=rocks.size()-1;i>=0;i--){Rock r=rocks.get(i);r.x-=r.speed*dt;if(r.x < -60)rocks.remove(i);
                    float bx=birdX*w, by=birdY*h;
                    if(Math.abs(r.x-bx)<r.size*.72f+18 && Math.abs(r.y-by)<r.size*.65f+15){playing=false;over=true;if(score>best){best=score;prefs.edit().putInt("best",best).apply();}}
                }
            }
            // Bird: chunky pixel sprite
            float bx=birdX*w, by=birdY*h;
            rect(c,0xFF6B3DB5,bx-20,by-9,34,23);rect(c,0xFFFFD45C,bx-16,by-13,29,21);
            rect(c,0xFFFFA92E,bx-4,by+5,15,8);rect(c,0xFFFFFFFF,bx+5,by-9,8,8);rect(c,0xFF20152F,bx+9,by-7,3,4);
            rect(c,0xFFFF8C35,bx+12,by-1,12,6);rect(c,0xFFFFB93E,bx-13,by+9,9,5);
            // Rocks
            for(Rock r:rocks){float s=r.size;rect(c,0xFF514A69,r.x-s/2,r.y-s/2,s,s);rect(c,0xFF817895,r.x-s/2+5,r.y-s/2-5,s*.55f,s*.35f);rect(c,0xFF302A45,r.x-s/2+3,r.y+s*.2f,s*.8f,s*.25f);}
            text(c,"SCORE "+score,24,42,22,0xFFFFFFFF);text(c,"BEST "+best,w-150,42,17,0xFFBDA8FF);
            if(!playing){
                rect(c,0xCC09071A,0,h*.32f,w,h*.34f);
                text(c,over?"GAME OVER":"BIRD DASH",w*.5f-(over?83:88),h*.43f,27,0xFFFFD45C);
                text(c,over?("SCORE "+score):"DRAG TO FLY",w*.5f-75,h*.49f,17,0xFFFFFFFF);
                text(c,over?"TAP TO RETRY":"TAP TO START",w*.5f-82,h*.56f,17,0xFFBDA8FF);
            } else postInvalidateDelayed(16);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            float x=e.getX(),y=e.getY();
            if(e.getAction()==MotionEvent.ACTION_DOWN){if(!playing){start();return true;} targetX=Math.max(.08f,Math.min(.88f,x/w));targetY=Math.max(.08f,Math.min(.88f,y/h));return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE && playing){targetX=Math.max(.08f,Math.min(.88f,x/w));targetY=Math.max(.08f,Math.min(.88f,y/h));return true;}
            return true;
        }
    }
}
